
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Mappa.id</title>
  <meta name="author" content="Tim Mappa">
  <meta name="description" content="Mappa berbagai Informasi GIS , Drone , Orthophoto  ">
  <meta name="keywords" content="Mappa berbagai Informasi GIS , Drone , Orthophoto ">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!--====== Font Google ======-->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@24,400,0,0" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,500;0,600;0,700;1,400&family=Roboto+Condensed:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet">
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css?v=1" rel="stylesheet">

</head>
<body>
<?php

if(isset($_POST['simpan'])){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $nohp = $_POST['nohp'];
    $message = $_POST['message'];

    // Include file PHPMailer
    require 'PHPMailer/class.phpmailer.php';
    require 'PHPMailer/class.smtp.php';

    // Buat objek PHPMailer
    $mail = new PHPMailer;

    // Konfigurasi SMTP
    $mail->isSMTP();
    $mail->SMTPDebug = 0; // 0 untuk non-debug, ganti dengan 2 untuk debugging
    $mail->Host = 'mail.selembardaun.com'; // Ganti dengan server SMTP Anda
    $mail->SMTPAuth = true;
    $mail->Username = 'noreply@selembardaun.com'; // Ganti dengan alamat email Anda
    $mail->Password = '!u@&vRN(jgNF'; // Ganti dengan kata sandi email Anda
    $mail->SMTPSecure = 'ssl'; // Anda dapat menggunakan 'tls' atau 'ssl' tergantung pada kebutuhan
    $mail->Port = 465; // Ganti dengan port SMTP yang sesuai

    // Set alamat email pengirim
    $mail->setFrom('noreply@selembardaun.com', 'MAPPA.ID');

    // Tambahkan alamat email penerima
    $mail->addAddress('a.nurrohman007@gmail.com', 'Nama Penerima');

    // Subjek email
    $mail->Subject = 'Pesan dari Kontak Form MAPPA.ID';

    // Isi pesan email
    // $mail->Body = 'Isi Pesan Email';
    $mail->MsgHTML("
    <b>Nama:</b><br/>
    $name<br/><br/>
    <b>Email:</b><br/>
    $email<br/><br/>
    <b>Nomor Telepon:</b><br/>
    $nohp<br/><br/>
    <b>Pesan:</b><br/>
    $message
	");

    // Kirim email
    if ($mail->send()) {
        echo "
        <script>
           Swal.fire(
            'Success',
            'Pesan telah berhasil terkirim.',
            'success'
          ).then((result) => {
              if (result.value) {
               window.location.href = 'index.php'
              }
          });
        </script>";
    } else {
        echo 'Email gagal terkirim. Error: ' . $mail->ErrorInfo;
    }
}
?>
  <section id="notification" class="text-center py-2 px-4">Selamat buat lutfi, 081316549997 sebagai kontributor mappa tembus 1 juta Ha.</section>
  <!-- ======= Header ======= -->
  
  <div class="position-relative">
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="index.html"><img src="assets/img/logo.png"></a></h1>
      <!-- Uncomment below if you prefer to use an image logo -->
      <!-- <a href="index.html" class="logo me-auto"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>-->

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Dashboard</a></li>
          <li><a class="nav-link scrollto" href="#about">Tentang</a></li>
          <li><a class="nav-link scrollto" href="#">Upload Data</a></li>
          <li><a class="nav-link scrollto" href="#map">Mappatile</a></li>
          <li><a class="nav-link scrollto" href="#partner">Partner</a></li>
          <li><a class="nav-link scrollto" href="#faq">FAQ</a></li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
          <li><a class="getstarted scrollto" href="https://accounts.google.com/o/oauth2/auth?response_type=code&redirect_uri=https%3A%2F%2Fmappa.id%2Fauth%2Fgoogle_login&client_id=269173757594-mgjhq8v6382icpk71beff3g2av4h6prf.apps.googleusercontent.com&scope=https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.profile+https%3A%2F%2Fwww.googleapis.com%2Fauth%2Fuserinfo.email&access_type=online&approval_prompt=auto"><span class="material-symbols-outlined me-1">person</span>gLogin</a></li>
        </ul>
          <button type="button" id="droneButton" class="drone-icon border-0 bg-transparent ms-2" data-bs-toggle="modal" data-bs-target="#iklanModal" fdprocessedid="l3vpp"><svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 28 28" fill="none">
          <path d="M23.1667 8.66667H20.8333V6.33333H23.1667C23.4761 6.33333 23.7728 6.21042 23.9916 5.99162C24.2104 5.77283 24.3333 5.47609 24.3333 5.16667C24.3333 4.85725 24.2104 4.5605 23.9916 4.34171C23.7728 4.12292 23.4761 4 23.1667 4H16.1667C15.8572 4 15.5605 4.12292 15.3417 4.34171C15.1229 4.5605 15 4.85725 15 5.16667C15 5.47609 15.1229 5.77283 15.3417 5.99162C15.5605 6.21042 15.8572 6.33333 16.1667 6.33333H18.5V8.66667H9.16667V6.33333H11.5C11.8094 6.33333 12.1062 6.21042 12.325 5.99162C12.5437 5.77283 12.6667 5.47609 12.6667 5.16667C12.6667 4.85725 12.5437 4.5605 12.325 4.34171C12.1062 4.12292 11.8094 4 11.5 4H4.5C4.19058 4 3.89383 4.12292 3.67504 4.34171C3.45625 4.5605 3.33333 4.85725 3.33333 5.16667C3.33333 5.47609 3.45625 5.77283 3.67504 5.99162C3.89383 6.21042 4.19058 6.33333 4.5 6.33333H6.83333V8.66667H4.5C3.57174 8.66667 2.6815 9.03542 2.02513 9.69179C1.36875 10.3482 1 11.2384 1 12.1667C1 13.0949 1.36875 13.9852 2.02513 14.6415C2.6815 15.2979 3.57174 15.6667 4.5 15.6667H6.95C7.13694 16.56 7.53273 17.3964 8.105 18.1073C6.76651 18.3551 5.5568 19.0631 4.68537 20.1088C3.81393 21.1546 3.33565 22.4721 3.33333 23.8333C3.33333 24.1428 3.45625 24.4395 3.67504 24.6583C3.89383 24.8771 4.19058 25 4.5 25C4.80942 25 5.10616 24.8771 5.32496 24.6583C5.54375 24.4395 5.66667 24.1428 5.66667 23.8333C5.66667 22.9051 6.03542 22.0148 6.69179 21.3585C7.34817 20.7021 8.23841 20.3333 9.16667 20.3333H12.6667V22.6667C12.6667 22.9761 12.7896 23.2728 13.0084 23.4916C13.2272 23.7104 13.5239 23.8333 13.8333 23.8333C14.1428 23.8333 14.4395 23.7104 14.6583 23.4916C14.8771 23.2728 15 22.9761 15 22.6667V20.3333H18.5C19.4283 20.3333 20.3185 20.7021 20.9749 21.3585C21.6313 22.0148 22 22.9051 22 23.8333C22 24.1428 22.1229 24.4395 22.3417 24.6583C22.5605 24.8771 22.8572 25 23.1667 25C23.4761 25 23.7728 24.8771 23.9916 24.6583C24.2104 24.4395 24.3333 24.1428 24.3333 23.8333C24.331 22.4719 23.8525 21.1543 22.9809 20.1085C22.1092 19.0628 20.8992 18.3548 19.5605 18.1073C20.1332 17.3965 20.5294 16.5601 20.7167 15.6667H23.1667C24.0949 15.6667 24.9852 15.2979 25.6415 14.6415C26.2979 13.9852 26.6667 13.0949 26.6667 12.1667C26.6667 11.2384 26.2979 10.3482 25.6415 9.69179C24.9852 9.03542 24.0949 8.66667 23.1667 8.66667ZM23.1667 13.3333H19.6667C19.3572 13.3333 19.0605 13.4562 18.8417 13.675C18.6229 13.8938 18.5 14.1906 18.5 14.5C18.5 15.4283 18.1313 16.3185 17.4749 16.9749C16.8185 17.6313 15.9283 18 15 18H12.6667C11.7384 18 10.8482 17.6313 10.1918 16.9749C9.53541 16.3185 9.16667 15.4283 9.16667 14.5C9.16667 14.1906 9.04375 13.8938 8.82496 13.675C8.60616 13.4562 8.30942 13.3333 8 13.3333H4.5C4.19058 13.3333 3.89383 13.2104 3.67504 12.9916C3.45625 12.7728 3.33333 12.4761 3.33333 12.1667C3.33333 11.8572 3.45625 11.5605 3.67504 11.3417C3.89383 11.1229 4.19058 11 4.5 11H23.1667C23.4761 11 23.7728 11.1229 23.9916 11.3417C24.2104 11.5605 24.3333 11.8572 24.3333 12.1667C24.3333 12.4761 24.2104 12.7728 23.9916 12.9916C23.7728 13.2104 23.4761 13.3333 23.1667 13.3333ZM16.1667 14.5C16.1667 15.1188 15.9208 15.7123 15.4832 16.1499C15.0457 16.5875 14.4522 16.8333 13.8333 16.8333C13.2145 16.8333 12.621 16.5875 12.1834 16.1499C11.7458 15.7123 11.5 15.1188 11.5 14.5C11.5039 14.2694 11.5433 14.0408 11.6167 13.8222C11.6932 13.9958 11.8109 14.1481 11.9596 14.2659C12.1083 14.3838 12.2834 14.4636 12.4699 14.4984C12.6564 14.5333 12.8486 14.5221 13.0298 14.4659C13.211 14.4097 13.3758 14.3102 13.5098 14.1759C13.6439 14.0417 13.7431 13.8768 13.7991 13.6955C13.855 13.5142 13.8658 13.322 13.8307 13.1356C13.7956 12.9491 13.7155 12.7741 13.5974 12.6256C13.4794 12.4771 13.3269 12.3596 13.1532 12.2833C13.3728 12.2106 13.602 12.1712 13.8333 12.1667C14.4522 12.1667 15.0457 12.4125 15.4832 12.8501C15.9208 13.2877 16.1667 13.8812 16.1667 14.5Z" fill="white"/>
          </svg></button>
        <i class="bi bi-list mobile-nav-toggle"></i>
        <div class="indonesia-flag"><img src="assets/img/indonesia-flag.jpg"></div>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  <!-- ======= Hero Section ======= -->
  <section id="hero" class="d-flex align-items-center">

    <div class="container">
      <div class="row">
        <div class="col-lg-6 d-flex flex-column justify-content-center pt-4 pt-lg-0 order-2 order-lg-1 text-white" data-aos="fade-up" data-aos-delay="200">
          <h1>YOUR MAP<br/>
            ENERGIZE THE NATION.<br/>
            <span>SHARE IT!</span>
          </h1>
          <p class="text">Petamu, energi untuk negeri.<br>
            Yuk Bagikan</p>
          <div class="d-sm-flex justify-content-center justify-content-lg-start">
            <a href="#" class="btn btn-primary">Upload Data</a>
            <a href="#" class="btn btn-outline">Dapatkan Info</a>
          </div>
        </div>
      </div>
    </div>

  </section><!-- End Hero -->
</div>

  <main id="main">

    <!-- ======= Call Section ======= -->
    <section id="call" class="calls section-bg py-3">
      <div class="container">

        <div class="row" data-aos="fade-in">

          <div class="col-12">
            <div class="d-sm-flex align-items-center justify-content-between">
              <h2 class="mb-0">Jangan ragu untuk berdiskusi bersama kami jika Anda memerlukan bantuan</h2>
              <a href="https://api.whatsapp.com/send?phone=6281319640604&text=Hallo,..." class="btn btn-primary"><img src="assets/img/wa-icon.png" class="me-1">Contact Us</a>
            </div>            
          </div>
        </div>

      </div>
    </section><!-- End Call Section -->

    <!-- ======= About Us Section ======= -->
    <section id="about" class="about">
      <div class="container" data-aos="fade-up">
        <div class="row content">
          <div class="col-sm-5 image-about">
            <img class="w-100" src="assets/img/about-image.jpg">
          </div>
          <div class="col-sm-7 ps-sm-5">
            <h2>Tentang MAPPA ID</h2>
            <p>Mappa ID, platform open source untuk semua kalangan. Kami menyediakan ruang berbagi terutama data peta drone ortho dengan tujuan dapat dimanfaatkan untuk banyak pihak.</p>
            <p>Menjadi kontributor Mappa.id adalah caramu mengkinikan Indonesia. Tunggu apalagi? Yuk sekarang!</p>
            <p>Silahkan ikuti petunjuknya. Klik tombol dibawah, selamat menjelajahi tanah air.</p>
            <p>Bagikan pengalamanmu ke teman-teman.</p>
            <a href="#map" class="btn btn-primary">Mulai Menjelajah</a>
            <div class="box-icon row">
                <div class="col-6">
                  <div class="icon-box">
                    <div class="icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="83" height="83" viewBox="0 0 83 83" fill="none">
                        <path d="M41.5872 41.5C53.0471 41.5 62.3372 32.2099 62.3372 20.75C62.3372 9.29009 53.0471 0 41.5872 0C30.1273 0 20.8372 9.29009 20.8372 20.75C20.8372 32.2099 30.1273 41.5 41.5872 41.5Z" fill="url(#paint0_linear_11_9)"/>
                        <path d="M41.5872 48.4167C24.4052 48.4358 10.4813 62.3597 10.4622 79.5417C10.4622 81.4517 12.0105 83 13.9205 83H69.2537C71.1637 83 72.712 81.4517 72.712 79.5417C72.6931 62.3597 58.7692 48.4357 41.5872 48.4167Z" fill="url(#paint1_linear_11_9)"/>
                        <defs>
                          <linearGradient id="paint0_linear_11_9" x1="22.8624" y1="0.749999" x2="53.349" y2="53.3544" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#477EE7"/>
                            <stop offset="1" stop-color="#12316D"/>
                          </linearGradient>
                          <linearGradient id="paint1_linear_11_9" x1="13.5" y1="49.0417" x2="30.5837" y2="102.102" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#477EE7"/>
                            <stop offset="1" stop-color="#12316D"/>
                          </linearGradient>
                        </defs>
                      </svg>
                    </div>
                    <h4>325,924</h4>
                    <div class="label-box">PENGUNJUNG</div>
                  </div>
                </div>
                <div class="col-6">
                  <div class="icon-box">
                    <div class="icon">
                      <svg xmlns="http://www.w3.org/2000/svg" width="83" height="83" viewBox="0 0 83 83" fill="none">
                        <g clip-path="url(#clip0_11_17)">
                          <path d="M67.4375 0H15.5625C11.4365 0.00457685 7.48075 1.64566 4.56321 4.56321C1.64566 7.48075 0.00457685 11.4365 0 15.5625L0 67.4375C0.00457685 71.5635 1.64566 75.5192 4.56321 78.4368C7.48075 81.3543 11.4365 82.9954 15.5625 83H67.4375C71.5635 82.9954 75.5192 81.3543 78.4368 78.4368C81.3543 75.5192 82.9954 71.5635 83 67.4375V15.5625C82.9954 11.4365 81.3543 7.48075 78.4368 4.56321C75.5192 1.64566 71.5635 0.00457685 67.4375 0ZM15.5625 10.375H67.4375C68.8133 10.375 70.1328 10.9215 71.1056 11.8944C72.0785 12.8672 72.625 14.1867 72.625 15.5625V67.4375C72.6259 68.1187 72.4919 68.7934 72.2308 69.4226C71.9696 70.0518 71.5864 70.623 71.1033 71.1033L40.9052 40.9052C38.311 38.3118 34.7931 36.855 31.125 36.855C27.4569 36.855 23.939 38.3118 21.3448 40.9052L10.375 51.875V15.5625C10.375 14.1867 10.9215 12.8672 11.8944 11.8944C12.8672 10.9215 14.1867 10.375 15.5625 10.375Z" fill="url(#paint0_linear_11_17)"/>
                          <path d="M53.6041 34.5833C58.3791 34.5833 62.25 30.7125 62.25 25.9375C62.25 21.1625 58.3791 17.2917 53.6041 17.2917C48.8292 17.2917 44.9583 21.1625 44.9583 25.9375C44.9583 30.7125 48.8292 34.5833 53.6041 34.5833Z" fill="#1447A8"/>
                        </g>
                        <defs>
                          <linearGradient id="paint0_linear_11_17" x1="7.5" y1="1.97714e-06" x2="77.5" y2="89.5" gradientUnits="userSpaceOnUse">
                            <stop stop-color="#4B85F6"/>
                            <stop offset="1" stop-color="#102A5B"/>
                          </linearGradient>
                          <clipPath id="clip0_11_17">
                            <rect width="83" height="83" fill="white"/>
                          </clipPath>
                        </defs>
                      </svg>
                    </div>
                    <h4>1,101,096</h4>
                    <div class="label-box">CAKUPAN (HA)</div>
                  </div>
                </div>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End About Us Section -->

    <!-- ======= Map Section ======= -->
    <section id="map" class="map section-bg">
      <div id="maps-view">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11546704.014279757!2d116.37681060519851!3d-2.2670915161370018!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!3m2!1sen!2sid!4v1697635404994!5m2!1sen!2sid" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
      </div>
    </section><!-- End Map Section -->

    <!-- ======= Partner Section ======= -->
    <section id="partner" class="partners section-bg">
      <div class="container">

        <div class="row" data-aos="fade-in">

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-1.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-2.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-3.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-4.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-5.png" class="img-fluid" alt="">
          </div>

          <div class="col-lg-2 col-md-4 col-6 d-flex align-items-center justify-content-center">
            <img src="assets/img/clients/client-6.png" class="img-fluid" alt="">
          </div>

        </div>

      </div>
    </section><!-- End Partner Section -->


    <!-- ======= Frequently Asked Questions Section ======= -->
    <section id="faq" class="faq">
      <div class="container" data-aos="fade-up">

        <div class="faq-heading">
          <div class="fw-bold text-site mb-1">FAQs</div>
          <h3 class="fw-bold fs-3">Punya pertanyaan?</h3>
          <p class="text-muted">MAPPA ID menjawab pertanyaan yang sering ditanyakan</p>
        </div>

        <div class="faq-list">
          <div class="row">
            <div class="col-md-6">
              <ul>
                <li data-aos="fade-up" data-aos-delay="100">
                  <a data-bs-toggle="collapse" data-bs-target="#faq-list-1" class="collapsed">Bagaimana caranya update metadata dan atau hapus MBTILES? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></a>
                  <div id="faq-list-1" class="collapse" data-bs-parent=".faq-list">
                    <p>Klik icon pencarian(icon kaca pembesar), masukkan nomor grid kemudian klik Search. Bila email di metadata sama dengan email yang digunakan untuk login maka akan ada link untuk <b style="color:#f00">Edit</b> dan <b style="color:#f00">Download</b>.</p>
                  </div>
                </li>
    
                <li data-aos="fade-up" data-aos-delay="200">
                  <a data-bs-toggle="collapse" data-bs-target="#faq-list-2" class="collapsed">Apa manfaatnya upload MBTILES ke mappa?	<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></a>
                  <div id="faq-list-2" class="collapse" data-bs-parent=".faq-list">
                    <p>
                      Sebagai kontributor, minimal punya portofolio kemampuan ngedron yang hasilnya bisa dipresentasikan/dilihat secara online tanpa harus investasi server dan aplikasi penunjang.
                    </p>
                  </div>
                </li>
              </ul>
            </div>
            <div class="col-md-6">
              <ul>
                <li data-aos="fade-up" data-aos-delay="100">
                  <a data-bs-toggle="collapse" data-bs-target="#faq-list-3" class="collapsed">Kenapa penampilan di pingir AOI putih/hitam? <i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></a>
                  <div id="faq-list-3" class="collapse" data-bs-parent=".faq-list">
                    <p> Pelajari cara  menbuat MBTILES di link berikut <a href="https://mappa.id/Cara_membuat_Tile_Map_MBTILES.pdf" target="cara">https://mappa.id/Cara_membuat_Tile_Map_MBTILES.pdf</a> </p>
                  </div>
                </li>
    
                <li data-aos="fade-up" data-aos-delay="200">
                  <a data-bs-toggle="collapse" data-bs-target="#faq-list-4" class="collapsed">Kenapa di Global Mapper nomor grid tidak muncul?		<i class="bi bi-chevron-down icon-show"></i><i class="bi bi-chevron-up icon-close"></i></a>
                  <div id="faq-list-4" class="collapse" data-bs-parent=".faq-list">
                    <p>
                      Sekalipun file *.mif bisa tampil namun datanya ada di file *.mid , jadi harus didownload dua duanya baru file *.mif nya dibuka di Global Mapper
                    </p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>

      </div>
    </section><!-- End Frequently Asked Questions Section -->


    <!-- ======= Cta Section ======= -->
    <section id="cta" class="cta">
      <div class="container" data-aos="fade-up">

        <div class="row">
          <div class="col-lg-9 text-center text-lg-start">
            <h3>Siapapun bisa menjadi kontributor.<br/>
              Bagikan info yang anda miliki.</h3>
          </div>
          <div class="col-lg-3 cta-btn-container text-center">
            <a href="https://api.whatsapp.com/send?phone=6281319640604&text=Hallo,..." class="cta-btn"><img src="assets/img/wa-icon.png" class="me-2">Contact Us</a>
          </div>
        </div>

      </div>
    </section><!-- End Cta Section -->


    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">
      <div class="container" data-aos="fade-up">
        <div class="row">
            <div class="col-md-4">
                <div class="section-title">
                    <h2>Contact</h2>
                    <p class="text-muted">Kami Siap Membantu Anda dengan Informasi yang Anda Butuhkan.</p>
                </div>
            </div>
          <div class="col-md-8 mt-0 mt-md-0 d-flex align-items-stretch">
            <form action="" method="post" role="form" class="php-email-form">
              <div class="row">
                <div class="form-group col-md-4">
                  <label for="name">
                    <div class="label-form">Nama</div>
                    <input type="text" name="name" class="form-control" id="name" required>
                  </label>
                </div>
                <div class="form-group col-md-4">
                  <label for="name"><div class="label-form">Email</div>
                    <input type="email" class="form-control" name="email" id="email" required>
                  </label>
                </div>
                <div class="form-group col-md-4">
                <label for="name"><div class="label-form">Nomor Telepon</div>
                  <input type="text" class="form-control" name="nohp" id="nohp" required>
                </label>
                </div>
              </div>
              <div class="form-group">
                <label for="name"><div class="label-form">Pesan</div>
                  <textarea class="form-control" name="message" rows="10" required></textarea>
                </label>
              </div>
              <div class="my-3">
                <div class="loading">Loading</div>
                <div class="error-message"></div>
                <div class="sent-message">Your message has been sent. Thank you!</div>
              </div>
              <div class="text-start"><input class="btn btn-primary mt-0 px-5" type="submit" name="simpan" value="Submit" id="butsave"></div>
            </form>
          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="container footer-bottom clearfix">
      <div class="copyright d-md-flex align-items-center justify-content-between">
        © Copyright 2023 Mappa
        <button type="button" id="snk" class="border-0 bg-transparent ms-2" data-bs-toggle="modal" data-bs-target="#snkModal" fdprocessedid="l3vpp">Syarat & Ketentuan</button>
      </div>
    </div>
  </footer><!-- End Footer -->
  
  <!-- Modal Iklan-->
  <div class="modal fade" id="iklanModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="iklanModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        <div class="modal-body">
          <img src="assets/img/iklan01.jpg" class="w-100">
        </div>
      </div>
    </div>
  </div>
  <!-- End Modal Iklan-->

  <!-- S&K Iklan-->
  <div class="modal fade" id="snkModal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="snkModal" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h2 class="mb-0">Syarat & Ketentuan</h2>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          
          <ol><li><p><strong>Lisensi Data:</strong> Pengguna mungkin diharuskan untuk setuju dengan lisensi yang mengatur penggunaan data geospasial yang mereka kontribusikan atau akses di platform. OSM, misalnya, menggunakan lisensi Open Database License (ODbL) untuk data yang disumbangkan.</p></li><li><p><strong>Kode Etik Kontribusi:</strong> Platform pemetaan mungkin memiliki kode etik atau panduan kontribusi yang harus diikuti oleh pengguna. Ini dapat mencakup pedoman untuk menambahkan, mengedit, atau memverifikasi data geospasial.</p></li><li><p><strong>Hak Cipta Kontribusi:</strong> Pengguna harus menerima bahwa data yang mereka kontribusikan akan dianggap bebas hak cipta dan dapat digunakan oleh siapa saja di bawah lisensi yang sesuai.</p></li><li><p><strong>Privasi dan Data Lokasi:</strong> S&amp;K mungkin mengatur penggunaan data lokasi dan informasi pribadi dalam kontribusi. Pengguna mungkin diharapkan untuk mematuhi hukum privasi yang berlaku.</p></li><li><p><strong>Larangan Konten Tidak Pantas:</strong> Platform pemetaan biasanya akan melarang konten yang tidak pantas, termasuk informasi palsu atau merugikan.</p></li><li><p><strong>Lisensi Penggunaan API:</strong> Jika platform pemetaan menyediakan API (Antarmuka Pemrograman Aplikasi) untuk pengguna, S&amp;K mungkin mencakup persyaratan penggunaan yang berlaku.</p></li><li><p><strong>Penyimpanan Data:</strong> S&amp;K mungkin mengatur berapa lama data yang diunggah atau disumbangkan akan disimpan dan kapan data tersebut dapat dihapus.</p></li><li><p><strong>Kewajiban Pengguna:</strong> Pengguna mungkin diharapkan untuk melaporkan kesalahan, pelanggaran, atau perubahan yang tidak sah dalam data serta menjaga kerahasiaan kata sandi dan informasi akun.</p></li><li><p><strong>Pemantauan dan Sanksi:</strong> Platform pemetaan biasanya memiliki hak untuk memantau aktivitas pengguna dan memberikan sanksi, termasuk pemblokiran akun, jika S&amp;K dilanggar.</p></li><li><p><strong>Perubahan S&amp;K:</strong> Seperti S&amp;K untuk situs web lainnya, platform pemetaan juga dapat mengubah S&amp;K, dan pengguna biasanya diharapkan untuk memeriksa S&amp;K secara berkala.</p></li><li><p><strong>Pengakuan Kontribusi:</strong> Beberapa platform pemetaan meminta pengguna untuk mengakui kontribusi mereka, yang dapat mencakup nama pengguna atau informasi serupa yang terlihat oleh pengguna lain.</p></li></ol>
        </div>
      </div>
    </div>
  </div>
  <!-- End S&K Iklan-->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <script>
    const myButton = document.getElementById('droneButton');
    const myModal  = document.getElementById('iklanModal');

    const modal = new Modal(myModal); // Instantiates your modal

    myButton.addEventListener('click', () => {
        modal.show(); // shows your modal
    });
    $(window).resize(function() {
    $("#header").css({"padding-top": $("#notification").height() });
  });

  </script>

</body>

</html>