<?php 
	include "classes/class.phpmailer.php";
	$mail = new PHPMailer;
	
	$mail->IsSMTP();
	
	$mail->SMTPSecure = 'ssl';
	
	$mail->Host = "localhost"; //hostname masing-masing provider email
	$mail->SMTPDebug = 0;
	$mail->Port = 465;
	$mail->SMTPAuth = true;
	
	$mail->Timeout = 60; // timeout pengiriman (dalam detik)
	$mail->SMTPKeepAlive = true; 
	
	$mail->Username = "noreply@selembardaun.com"; //user email
	$mail->Password = "!u@&vRN(jgNF"; //password email
	$mail->SetFrom("noreply@selembardaun.com","Nama pengirim yang muncul"); //set email pengirim
	$mail->Subject = "Pemberitahuan Email dari Website"; //subyek email
	$mail->AddAddress("haniprijali007@gmail.com","Nama penerima yang muncul"); //tujuan email
	$mail->MsgHTML("Pengiriman Email Dari Website");
	
	if($mail->Send()) echo "Message has been sent";
	else echo "Failed to sending message";
?>
